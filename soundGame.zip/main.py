import scipy.io.wavfile as wav
import sounddevice as sd
import numpy as np
import speech_recognition as sr
from colorama import Fore
import time
from googletrans import Translator
from kayit_mantik import kayit
import random

def yuzde(hiz=0.5,artis=20,realistic=False):
    percent=0
    percent = max(0, min(100, percent))
    artis_static=artis
    if realistic:
        kayma_list=[0,1,2,-1,-2,3,-3,4,-4]
    while True:
        if percent>=100:
            print("100 %"," ","█"*100)
            break
        if realistic:
            artis=artis_static
            kayma=random.choice(kayma_list)
            if kayma<=0:
                artis+=kayma
            else:
                percent+=kayma
        else:
            None
        print(percent,"%","  ","█"*percent,"░"*(100-percent))
        percent+=artis
        time.sleep(hiz)

print("Size bir kelime vereceğiz, İngilizce telaffuzunu söyleyeceksiniz! \n")
time.sleep(2)
zorluklar=["kolay","orta","zor"]
debug=True
while True:
    zorluk=input(Fore.YELLOW+"Zorluk seviyesi seçiniz: (kolay,orta,zor) \n"+Fore.WHITE)
    if zorluk.lower() in zorluklar:
        zorluk=zorluk.lower()
        break
    else:
        print(Fore.RED+"Yazdığınız zorluk bulunamadı, lütfen geçerli bir zorluk giriniz... \n")
        time.sleep(1.4)
seviyeye_gore_kelimeler = {
    "kolay": ["cat", "dog", "apple", "milk", "sun"],
    "orta": ["banana", "school", "friend", "window", "yellow"],
    "zor": ["technology", "university", "information", "pronunciation", "imagination"]
}
seviyeye_gore_kelimeler_turkce={
    "kolay": ["kedi", "köpek", "elma", "süt", "güneş"],
    "orta": ["muz", "okul", "arkadaş", "pencere", "sarı"],
    "zor": ["teknoloji", "üniversite", "bilgi", "telaffuz", "hayal gücü"]
}
while True:
    kelime=random.choice(seviyeye_gore_kelimeler_turkce[zorluk])
    if debug:
        print(Fore.BLUE+kelime)
    time.sleep(0.6)
    text=kayit(lang="en-US")
    if debug and not text==None:
        print(Fore.BLUE+text)
    if text==None:
        print("Bir hata oluştu")
        break
    print(f"Dedin ki: {text}")
    if text.lower() in seviyeye_gore_kelimeler["kolay"] if zorluk=="kolay"  else seviyeye_gore_kelimeler["orta"] if zorluk=="orta" else seviyeye_gore_kelimeler["zor"]:
        print(Fore.GREEN+"Aferin🎉 \n")
        while True:
            devam=input(Fore.YELLOW+"Sonraki oyuna geçilsin mi? E/h \n"+Fore.WHITE)
            if devam=="E":
                break
            if devam=="h":
                break
            else:
                continue
        if devam=="E":
            break
    else:
        print(Fore.RED+"Başaramadın😿")
print(Fore.WHITE+"Geçiliyor... \n")
time.sleep(0.3)
yuzde(artis=12,realistic=True)
while True:
    time.sleep(2.3)
    print(Fore.WHITE+"Bir polisten kaçıyorsun, önüne direk çıktı! SAĞ VEYA SOL de")
    text=kayit(3,lang="tr-TR")
    if debug:
        time.sleep(3)
        if not text==None:
            print(Fore.BLUE+text)
    if (not text in "sol" or not text in "sağ") and text!=None:
        print(Fore.LIGHTRED_EX+"Direğe çarptın🫣")
        break
    else:
        if text!=None:
            print(Fore.GREEN+"Kaçtın😎")
        break