import scipy.io.wavfile as wav
import sounddevice as sd
import numpy as np
import speech_recognition as sr
from colorama import Fore
import time
from googletrans import Translator



def kayit(duration=5,lang="tr"):
    text=None
    duration = duration  # kayıt saniyeleri
    sample_rate = 44100
    print("Şimdi konuşun 🎤")
    recording = sd.rec(
    int(duration * sample_rate), # kaydedilecek örnek sayısı
    samplerate=sample_rate,      # örnekleme hızı
    channels=1,                  # 1, mono kayıt anlamına gelir.
    dtype="int16")               # kayıtlı örnekler için veri türü
    sd.wait()  # kayıt bitene kadar beklemek
    wav.write("kayit.wav",sample_rate,recording)
    print(Fore.GREEN+"Kayıt alındı! Kaydınız kayit.wav'dır")
    print(Fore.WHITE)
    recognizer=sr.Recognizer() # Recognizer nesnesini metne dönüştürür.
    with sr.AudioFile("kayit.wav") as source:
        audio=recognizer.record(source)
    try:
        text=recognizer.recognize_google(audio,language=lang)
    except KeyboardInterrupt:
        print("Elini klavyeden çek")
    except sr.RequestError as e:
        print(f"API hatası: {e}")
    except Exception as e:
        print("Bir hata oluştu... \n")
        print(e)
    except sr.UnknownValueError:
        print("Konuşma tanınamadı.")
    return text